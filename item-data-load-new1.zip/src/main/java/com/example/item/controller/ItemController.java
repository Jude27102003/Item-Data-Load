
package com.example.item.controller;

import com.example.item.entity.Item;
import com.example.item.service.ItemService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/item")
public class ItemController {

    private final ItemService itemService;

    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    /**
     * Save a new item.
     * @param item the item to be saved
     * @return ResponseEntity with status 201
     */
    @PostMapping("/save")
    public ResponseEntity<Item> saveItem(@Valid @RequestBody Item item) {
        Item savedItem = itemService.saveItem(item);
        return new ResponseEntity<>(savedItem, HttpStatus.CREATED);
    }

    /**
     * Get an item by ID.
     * @param id the ID of the item
     * @return ResponseEntity with status 200
     */
    @GetMapping("/{id}")
    public ResponseEntity<Item> getItemById(@PathVariable Long id) {
        return itemService.getItemById(id)
                .map(item -> new ResponseEntity<>(item, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * Update an item by ID.
     * @param id the ID of the item
     * @param item the updated item data
     * @return ResponseEntity with status 201
     */
    @PutMapping("/{id}")
    public ResponseEntity<Item> updateItem(@PathVariable Long id, @Valid @RequestBody Item item) {
        return new ResponseEntity<>(itemService.updateItem(id, item), HttpStatus.CREATED);
    }

    /**
     * Delete an item by ID.
     * @param id the ID of the item
     * @return ResponseEntity with status 202 Accepted
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable Long id) {
        itemService.deleteItem(id);
        return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }

    /**
     * Get all items.
     * @return list of all items
     */
    @GetMapping
    public ResponseEntity<List<Item>> getAllItems() {
        return new ResponseEntity<>(itemService.getAllItems(), HttpStatus.OK);
    }
}
