
package com.example.item.service.impl;

import com.example.item.entity.Item;
import com.example.item.repository.ItemRepository;
import com.example.item.service.ItemService;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.List;
import jakarta.validation.ValidationException;

@Service
public class ItemServiceImpl implements ItemService {

    private final ItemRepository itemRepository;

    public ItemServiceImpl(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    @Override
    public Item saveItem(Item item) {
        validateItemPack(item);
        return itemRepository.save(item);
    }

    @Override
    public Optional<Item> getItemById(Long id) {
        return itemRepository.findById(id);
    }

    @Override
    public Item updateItem(Long id, Item item) {
        validateItemPack(item);
        item.setId(id);
        return itemRepository.save(item);
    }

    @Override
    public void deleteItem(Long id) {
        itemRepository.deleteById(id);
    }

    @Override
    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    private void validateItemPack(Item item) {
        if ("Y".equalsIgnoreCase(item.getItemPack())) {
            if (item.getItemContents() == null) {
                throw new ValidationException("Item contents must be populated when Item Pack is 'Y'");
            }
        } else if ("N".equalsIgnoreCase(item.getItemPack())) {
            if (item.getItemContents() != null) {
                throw new ValidationException("Item contents must not be populated when Item Pack is 'N'");
            }
        }
    }
}
