
package com.example.item.service;

import com.example.item.entity.Item;
import java.util.Optional;
import java.util.List;

public interface ItemService {
    Item saveItem(Item item);
    Optional<Item> getItemById(Long id);
    Item updateItem(Long id, Item item);
    void deleteItem(Long id);
    List<Item> getAllItems();
}
